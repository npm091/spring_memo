function setColSpan( $n ) {
    var $tdElementReference = document.getElementById( "m1" );
    $tdElementReference.rowSpan = $n;
    var $tdElementReference = document.getElementById( "m2" );
    $tdElementReference.rowSpan = $n;
    // document.getElementById( "sampleOutput" ).innerHTML = $tdElementReference.rowSpan;
}

window.onload = function() {
  var tbl=document.getElementById('tbl');
  var cell1 = null;
  var cell2 = null;
  var cell1val = "";
  var cell2val = "";
  var rowspancount1 = 0;
  var rowspancount2 = 0;
  var eraseCells1 = [];
  var eraseCells2 = [];
  for (var i=0, rowLen=tbl.rows.length; i < rowLen; i++) {
    for (var j=0, colLen=tbl.rows[i].cells.length ; j < colLen; j++) {
      var cells = tbl.rows[i].cells[j];
      if (j == 0) {
        if (cell1val != cells.innerHTML ) {
          if (rowspancount1 > 0) {
            for (var k=0; k < eraseCells1.length; k++) {
              eraseCells1[k].parentNode.removeChild(eraseCells1[k]);
            }
            eraseCells1 = [];
            cell1.rowSpan = rowspancount1 + 1;
          }
          cell1 = cells;
          cell1val = cells.innerHTML ;
          rowspancount1 = 0;
        } else {
          rowspancount1++;
          eraseCells1.push(cells);
        }
      }
      if (j == 3) {
        if (cell2val != cells.innerHTML ) {
          if (rowspancount2 > 0) {
            for (var k=0; k < eraseCells2.length; k++) {
              eraseCells2[k].parentNode.removeChild(eraseCells2[k]);
            }
            eraseCells2 = [];
            cell2.rowSpan = rowspancount2 + 1;
          }
          cell2 = cells;
          cell2val = cells.innerHTML ;
          rowspancount2 = 0;
        } else {
          rowspancount2++;
          eraseCells2.push(cells);
        }
      }
    }
  }
};

function setRowspan() {
  var tbl=document.getElementById('tbl');
  var cell1 = null;
  var cell2 = null;
  var cell1val = "";
  var cell2val = "";
  var rowspancount1 = 0;
  var rowspancount2 = 0;
  var eraseCells1 = [];
  var eraseCells2 = [];
  for (var i=0, rowLen=tbl.rows.length; i < rowLen; i++) {
    for (var j=0, colLen=tbl.rows[i].cells.length ; j < colLen; j++) {
      var cells = tbl.rows[i].cells[j];
      if (j == 0) {
        if (cell1val != cells.innerHTML ) {
          if (rowspancount1 > 0) {
            for (var k=0; k < eraseCells1.length; k++) {
              eraseCells1[k].parentNode.removeChild(eraseCells1[k]);
            }
            eraseCells1 = [];
            cell1.rowSpan = rowspancount1 + 1;
          }
          cell1 = cells;
          cell1val = cells.innerHTML ;
          rowspancount1 = 0;
        } else {
          rowspancount1++;
          eraseCells1.push(cells);
        }
      }
      if (j == 3) {
        if (cell2val != cells.innerHTML ) {
          if (rowspancount2 > 0) {
            for (var k=0; k < eraseCells2.length; k++) {
              eraseCells2[k].parentNode.removeChild(eraseCells2[k]);
            }
            eraseCells2 = [];
            cell2.rowSpan = rowspancount2 + 1;
          }
          cell2 = cells;
          cell2val = cells.innerHTML ;
          rowspancount2 = 0;
        } else {
          rowspancount2++;
          eraseCells2.push(cells);
        }
      }
    }
  }
}

