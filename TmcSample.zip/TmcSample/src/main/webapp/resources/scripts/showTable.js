window.onload = function() {
  formatTbl('tbl');
};

/**
 * テーブルをフォーマットする
 *
 * @param tblName テーブル名
 */
function formatTbl(tblName) {
  // (1) 大分類の重複をチェックしてrowSpanリスト作成
  var tbl = document.getElementById(tblName);
  var rowSpanList = getRowSpnlList(tbl, 1);
  // console.log("rowSpanList:" + rowSpanList);
  // (2) 合計値を計算、設定する
  calcTotal(tbl, rowSpanList, 4, 6);
  // (3) rowSpanを設定する (※ 後ろのカラムから設定する)
  setRowSpn(tbl, rowSpanList, 7);
  setRowSpn(tbl, rowSpanList, 6);
  setRowSpn(tbl, rowSpanList, 1);
  // (4) colSpanを設定する
  setColSpan(tbl, 1, 2);
}

/**
 * colSpanを実行する
 *
 * @param tbl  テーブル
 * @param col1 大分類カラム
 * @param col2 中分類カラム
 */
function setColSpan(tbl, col1, col2) {
  for (var i = 0, yLen = tbl.rows.length; i < yLen; i++) {
    var cellVal = tbl.rows[i].cells[col2].innerHTML;
    if (!cellVal) {
      tbl.rows[i].cells[col2].parentNode.removeChild(tbl.rows[i].cells[col2]);
      tbl.rows[i].cells[col1].colSpan = 2;
    }
  }
}

/**
 * 指定カラムの重複をチェックしrowSpanリストを作成
 *
 * @param  tbl     テーブル
 * @param  colNo   指定カラム
 * @return {Array} rowSpanリスト
 */
function getRowSpnlList(tbl, colNo) {
  var rowSpanList = [];
  var cellVal = "";
  var count = 0;

  for (var i = 0, yLen = tbl.rows.length; i < yLen; i++) {
    var cell = tbl.rows[i].cells[colNo];
    // console.log("cellVal:" + cell.innerHTML);
    if (cellVal == cell.innerHTML) {
      count++;
    } else if (i != 0) {
      rowSpanList.push(count);
      count = 0;
    }
    cellVal = cell.innerHTML;
  }
  rowSpanList.push(count);
  return rowSpanList;
}

/**
 * 合計の計算、設定
 *
 * @param  tbl        テーブル名
 * @param rowSpanList rowSpanリスト
 * @param  col1       点数カラムNo
 * @param  col2       合計カラムNo
 */
function calcTotal(tbl, rowSpanList, col1, col2) {
  var idx = 0;
  var total = 0;

  for (let i in rowSpanList) {
    var count = rowSpanList[i];
    // console.log("count:" + count);
    for (var j = 0; j <= count; j++) {
      // 最初に点数をそのまま合計値にコピーする
      var tensu = tbl.rows[idx + j].cells[col1].innerHTML;
      tbl.rows[idx + j].cells[col2].innerHTML = tensu;
      // console.log("tensu:" + tensu);
      // 大分類が重複していた場合は合計に加算
      if ((count > 0) && Number(tensu)) {
        total += Number(tensu);
        // console.log("total:" + total);
      }
    }
    // 大分類が重複していた場合は合計を設定
    if (count > 0) {
      tbl.rows[idx].cells[col2].innerHTML = total;
      total = 0;
    }
    idx += j;
  }
}

/**
 * rowSpanを実行する
 *
 * @param tbl         テーブル名
 * @param rowSpanList rowSpanリスト
 * @param colNo       rowSpanを実行するカラム番号
 */
function setRowSpn(tbl, rowSpanList, colNo) {
  var idx = 0;

  for (let i in rowSpanList) {
    var count = rowSpanList[i];
    if (count > 0) {
      // rowSpanをする前にremoveChildをしないとtableの形が崩れる
      for (var j = 0; j < count; j++) {
        var cell = tbl.rows[idx + j + 1].cells[colNo];
        // console.log("cell:" + cell.innerHTML);
        cell.parentNode.removeChild(cell);
      }
      // 先頭行cellにrowSpanを設定する
      tbl.rows[idx].cells[colNo].rowSpan = count + 1;
    }
    idx = idx + count + 1;
  }
}