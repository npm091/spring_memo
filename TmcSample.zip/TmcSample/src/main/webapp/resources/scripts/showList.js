// call when form invocation
$(document).ready(function() {
  // console.log('hidden.nendo=' + document.getElementById("hNendo").value);
  // console.log('hidden.chotatsuKbnNo=' + document.getElementById("hChotatsuKbnNo").value);
});

function register() {
  openDialog("/register?nendo=2018&chotatsuKbnNo=01", "デモ", 500, 600, demoClose);
}

function demoClose(event, ui, btn) {

}

function openDialog(url, title, width, height, callbackClose) {
  var iframeStyle = 'min-width :    100%; ' +
                    'height:        100%; ' +
                    'padding-top:    0.2em; ' +
                    'padding-right:  0; ' +
                    'padding-bottom: 0.2em; ' +
                    'padding-left:   0.3em; ' +
                    'border: 1px blue solid;'
                    ;
  $("body").after('<input id="dialogResult" type="hidden" value="" />');
  $("body").after('<input id="dialogData" type="hidden" value="" />');
  var iframe = $('<iframe id="commonDialog" frameboder="2" src="' + url + '" style="' + iframeStyle + '" />');
  var dialogOptions = {
    width : width,
    height : height,
    title : title,
    modal : true,
    allowtransperentry : false,
    open : function() {
      $(".ui-dialog-titlebar-close").hide();
    },
    buttons: {
      "close" : function() {
        $(this).dialog("close");
      }      
    }
/*
    close : function(event, ui) {
      var $clickedButton = $(this).data('clickedButton');
      callbackClose(event, ui, $clickedButton);
    }
*/    
  };
  iframe.dialog(dialogOptions);
}

// update select options 
function createSelectists() {
  // request parameter
  var request = {
    nendo: "",
    chotatsuKbnNo: ""
  };

  var nendo = document.getElementById("selector.nendo").value;
  var chotatsuKbnNo = document.getElementById("selector.chotatsuKbnNo").value;
  request.nendo = nendo;
  request.chotatsuKbnNo = chotatsuKbnNo;
  console.log('nendo=' + nendo);
  console.log('chotatsuKbnNo=' + chotatsuKbnNo);
  $.ajax({
    type: "POST",
    url: "/updateSelectList",
    dataType: "json",
    data: JSON.stringify(request),
    async: true,
    contentType: "application/json",
  }).done(function(data) {
    // console.log('data.nendo=' + data.nendo);
    // console.log('data.chotatsuKbnNo=' + data.chotatsuKbnNo);
    createSelOption("selector.bukyokuNo", data.bukyokuList);
    createSelOption("selector.kashoNo", data.kashoList);
    createSelOption("selector.gyoshuNo", data.gyoshuList);
    var nendo = document.getElementById("selector.nendo").value;
    document.getElementById("hNendo").innerHTML = data.nendo;
    document.getElementById("hChotatsuKbnNo").innerHTML = data.chotatsuKbnNo;
  }).fail(function(MLHttpRequest, textStatus, errorThrown) {
    console.log("Error!：" + textStatus + ":\n" + errorThrown);
  });
}

// search data 
function searchData() {
  // request parameter
  var request = {
    nendo: "",
    chotatsuKbnNo: ""
  };
  var nendo = document.getElementById("selector.nendo").value;
  var chotatsuKbnNo = document.getElementById("selector.chotatsuKbnNo").value;
  request.nendo = nendo;
  request.chotatsuKbnNo = chotatsuKbnNo;
  console.log('nendo=' + nendo);
  console.log('chotatsuKbnNo=' + chotatsuKbnNo);
  $.ajax({
    type: "POST",
    url: "/searchData",
    dataType: "json",
    data: JSON.stringify(request),
    async: true,
    contentType: "application/json",
  }).done(function(data) {
    // console.log('data=' + data);
    createTable(data);
  }).fail(function(MLHttpRequest, textStatus, errorThrown) {
    console.log("Error!：" + textStatus + ":\n" + errorThrown);
  });
}

// create data table
function createTable(data) {
  var table = document.getElementById("dataTable");

  // 
  while (table.rows[1]) table.deleteRow(1);

  // 
  for (var i in data) {
    console.log("jiki:" + data[i].jiki);
    var row = table.insertRow(-1);
    addline(row, data[i]);
  }
}

// create a lien　of data table
function addline(row, line) {
  c1 = row.insertCell(-1);
  c2 = row.insertCell(-1);
  c3 = row.insertCell(-1);
  c4 = row.insertCell(-1);
  c5 = row.insertCell(-1);
  c6 = row.insertCell(-1);
  c1.innerHTML = line.jiki;
  c2.innerHTML = line.kenmei;
  c3.innerHTML = line.bukyoku;
  c4.innerHTML = line.kasyo;
  c5.innerHTML = line.gyoshu;
  c6.innerHTML = line.biko;
}

// file upload
function dummy() {
  console.log("dummy is called");
  return false;
}

// file upload
function upload() {
  document.getElementById('mform').action = '/fupload';
}

// file dowload
function download() {
  document.getElementById('mform').action = '/fdownload';
}

// save hidden data before submit
function saveInfo() {
  var nendo = document.getElementById("selector.nendo").value;
  document.getElementById("hNendo").innerHTML = nendo;
  var chotatsuKbnNo = document.getElementById("selector.chotatsuKbnNo").value;
  document.getElementById("hChotatsuKbnNo").innerHTML = chotatsuKbnNo;
  console.log('form.selector.nendo=' + nendo);
  return true;
}

// create select options
function createSelOption(selId, map) {
  var element = document.getElementById(selId);
  while (element.firstChild)
    element.removeChild(element.firstChild);

  var keys = [];
  for (var key in map)
    keys.push(key);
  keys.sort(mapKeyCompare);

  for (var ikey in keys) {
    op = document.createElement("option");
    key = keys[ikey];
    op.value = key;
    op.text = map[key];
    document.getElementById(selId).appendChild(op);
  }
}

// comparision definition
function mapKeyCompare(a, b) {
  return a - b;
}