(function($)
{
	// ロードイベント
	$(function()
	{
		$(".menu dd").hide();
		$(".menu dt").each(function(i)
		{
			$(this).click(function()
			{
				$(".menu dd").eq(i).toggle(300);
			});
		});

	});
})(jQuery);
