package com.tmc.wata.model;

import java.io.Serializable;
import java.util.Map;

import lombok.Data;

@Data
public class RegisterForm implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 1L;

  private String nendo;

  private String chotatsuKbnNo;

  private String bukyokuNo;

  private String kashoNo;

  private String gyoshuNo;

  private Map<String, String> nendoList;

  private Map<String, String> chotatsuKbnList;

  private Map<String, String> bukyokuList;

  private Map<String, String> kashoList;

  private Map<String, String> gyoshuList;

  private String jiki;

  private String kenmei;

  private Integer tensu;

  private String biko;

  /** input length validation list */
  /** 変数名, 変数和名, min, max */
  private String[][] validList = {
      {"jiki", "時期", "1", "10"},
      {"kenmei", "件名", "2", "20"},
      {"tensu", "点数", "1", "3"},
      {"biko", "備考", "5", "10"},
  };
}
