package com.tmc.wata.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.tmc.wata.model.CategoryTable;
import com.tmc.wata.model.ShowTableForm;

@Controller
public class ShowTableController
{

  /** sl4j logger */
  Logger logger = LoggerFactory.getLogger(ShowTableController.class);

  /**
   * init - 画面の初期化
   *
   * @param model
   * @return
   */
  @RequestMapping(value = "/showTable", method = RequestMethod.GET)
  public String init(
      Model model) {
    return "showTable";
  }

  /**
   * setup form - 全てのリクエストの前に実行される
   *
   * @param oldform
   * @return
   */
  @ModelAttribute("ShowTableForm")
  public ShowTableForm setUpShowList(
      @ModelAttribute ShowTableForm form) {
    List<CategoryTable> list = new ArrayList<CategoryTable>();
    list.add(new CategoryTable("10", "陸上", "100m", "人気", 10, 0, 40));
    list.add(new CategoryTable("10", "陸上", "200m", "人気", 10, 0, 40));
    list.add(new CategoryTable("10", "陸上", "400m", "人気", 10, 0, 40));
    list.add(new CategoryTable("10", "陸上", "800m", "人気", 10, 0, 40));
    list.add(new CategoryTable("10", "陸上", "マラソン", "人気1", 20, 0, 40));
    list.add(new CategoryTable("20", "水泳", "100m", "人気", 10, 0, 40));
    list.add(new CategoryTable("20", "水泳", "200m", "人気", 10, 0, 40));
    list.add(new CategoryTable("20", "水泳", "800m", "人気1", 10, 0, 40));
    list.add(new CategoryTable("30", "相撲", "", "人気1", 10, 0, 40));
    list.add(new CategoryTable("40", "ボクシング", "ストロー", "人気", 20, 0, 50));
    list.add(new CategoryTable("40", "ボクシング", "フライ", "人気", 20, 0, 50));
    list.add(new CategoryTable("40", "ボクシング", "ライト", "人気", 20, 0, 50));
    list.add(new CategoryTable("40", "ボクシング", "ヘビー", "人気1", 20, 0, 50));
    form.setCategoryList(list);
    return form;
  }

  /**
   * save - 「保存」ボタン押下で実行
   *
   * @param model
   * @param form
   * @return
   */
  @RequestMapping(value = "/showTable", params = "btnSave", method = RequestMethod.POST)
  public String btnSaveSubmit(
      Model model,
      @ModelAttribute ShowTableForm form) {
    List<CategoryTable> list = form.getCategoryList();
    for (CategoryTable tbl : list) {
      logger.info("{}: {}", tbl.getCategory1() + "-" + tbl.getCategory2(), tbl.getPoint());
    }
    logger.info("form.gtotal={}", form.getGtotal());
    return "showTable";
  }

}
