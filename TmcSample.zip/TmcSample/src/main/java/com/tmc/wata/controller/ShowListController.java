package com.tmc.wata.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;
import com.tmc.wata.model.ListApi;
import com.tmc.wata.model.ListTable;
import com.tmc.wata.model.Selector;
import com.tmc.wata.model.ShowListForm;
import com.tmc.wata.service.ListService;

/**
 * Handles requests for the application home page.
 */
@Controller
public class ShowListController
{
  /** sl4j logger */
  Logger logger = LoggerFactory.getLogger(ShowListController.class);

  @Autowired
  private ListService service;

  @Autowired
  ResourceLoader resourceLoader;

  private static final String UPLOAD_DIR = "D:/usr/tmp/";


  /**
   * init - 画面の初期化
   *
   * @param model
   * @return
   */
  @RequestMapping(value = "/showList", method = RequestMethod.GET)
  public String init(
      Model model,
      @ModelAttribute ShowListForm form) {
//    ShowListForm form = new ShowListForm();
    service.setupShowListForm(form);
    model.addAttribute("ShowListForm", form);
    return "showList";
  }

  /**
   * setup form - 全てのリクエストの前に実行される
   *
   * @param oldform
   * @return
   */
  @ModelAttribute("ShowListForm")
  public ShowListForm setUpShowList(
      @ModelAttribute ShowListForm form) {
//    ShowListForm newform = new ShowListForm();
//    BeanUtils.copyProperties(form, newform);
    Selector selector = form.getSelector();
    if (selector == null) {
      selector = new Selector();
      form.setSelector(selector);
    }
    service.setupShowListForm(form);
    selector.setBukyokuNo("103");
    return form;
  }

  /**
   * search - 「検索」ボタン押下で実行
   *
   * @param model
   * @param form
   * @return
   */
  @RequestMapping(value = "/showList", params = "btnSearch", method = RequestMethod.POST)
  public String search(
      Model model,
      @ModelAttribute("ShowListForm") ShowListForm form) {
    Selector selector = form.getSelector();
    logger.info("form.nendo={}", selector.getNendo());
    logger.info("form.chotatsuKbnNo={}", selector.getChotatsuKbnNo());
    logger.info("form.bukyokuNoNo={}", selector.getBukyokuNo());
    logger.info("form.kashoNo={}", selector.getKashoNo());
    logger.info("form.gyoshuNo={}", selector.getGyoshuNo());
    return "showList";
  }

  /**
   * search - 「検索(Ajax)」ボタン押下で実行
   *
   * @param reqJson
   * @return
   */
  @ResponseBody
  @RequestMapping(value = "/searchData", method = RequestMethod.POST,
    consumes = MediaType.APPLICATION_JSON_VALUE,
    produces = "text/plain;charset=UTF-8")
  public String searchAjax(@RequestBody String reqJson) {
    Gson gson = new Gson();
    ListApi req = gson.fromJson(reqJson, ListApi.class);
    logger.info("req.nendo={}", req.getNendo());
    logger.info("req.chotatsuKbnNo={}", req.getChotatsuKbnNo());
    List<ListTable> list = service.getTableList(req.getNendo(), req.getChotatsuKbnNo());
    String result = gson.toJson(list);
    return result;
  }

  /**
   * Upload - 「アップロード」ボタン押下で実行
   *
   * @param form
   * @param file
   * @return
   */
  @RequestMapping(value = "/showList", params = "btnUpload", method = RequestMethod.POST)
  public String fileUploadComplete(
      Model model, // model and view
      @ModelAttribute ShowListForm form,
      @RequestParam("FileUploadForm") MultipartFile file) {
    logger.info("fupload (POST)");

    String loadfile = file.getOriginalFilename();
    logger.info("loadfile={}", loadfile);
    if (null == loadfile || "".equals(loadfile)) {
      return "showList";
    }
    String saveFile = UPLOAD_DIR + file.getName() + yyyymmddhhss() + ".csv";
    logger.info("savefile={}", saveFile);
    byte[] bytes = null;
    try {
      bytes = file.getBytes();
      BufferedOutputStream uploadFileStream =
          new BufferedOutputStream(new FileOutputStream(new File(saveFile)));
      uploadFileStream.write(bytes);
      uploadFileStream.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
    return "showList";
  }

  /**
   * download - 「ダウンロード」ボタン押下で実行
   *
   * @param form
   * @return
   * @throws IOException
   */
  @RequestMapping(value = "/fdownload", method = RequestMethod.POST)
  public ResponseEntity<byte[]> download(
      @ModelAttribute ShowListForm form)
      throws IOException {
    logger.info("fdownload (POST)");
    HttpHeaders h = new HttpHeaders();
    Selector selector = form.getSelector();
    String filePath = selector.getNendo() + selector.getChotatsuKbnNo() + ".csv";
    h.add("Content-Type", "text/csv; charset=Shift_JIS");
    h.setContentDispositionFormData("filename", filePath);
    String buff = service.getTableData(selector.getNendo(), selector.getChotatsuKbnNo());
    return new ResponseEntity<>(buff.getBytes("Shift_JIS"), h, HttpStatus.OK);
  }

  /**
   * select update(Ajax) - 「年度、調達区分」変更で実行
   *
   * @param reqJson
   * @return
   */
  @ResponseBody
  @RequestMapping(value = "/updateSelectList", method = RequestMethod.POST,
  consumes = MediaType.APPLICATION_JSON_VALUE, produces = "text/plain;charset=UTF-8")
//    headers = {"content-type=*", "accept=application/json"})
  public String selUpdate(@RequestBody String reqJson) {
    Gson gson = new Gson();
    ListApi req = gson.fromJson(reqJson, ListApi.class);
    logger.info("req.nendo={}", req.getNendo());
    logger.info("req.chotatsuKbnNo={}", req.getChotatsuKbnNo());
    ListApi res = service.getSelectList(req.getNendo(), req.getChotatsuKbnNo());
    String result = gson.toJson(res);
    return result;
  }

  /**
   * yyyymmdd - 年月日時分秒の文字列
   *
   * @return
   */
  private String yyyymmddhhss()  {
    Date dt = new Date();
    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmss");
    return sdf.format(dt);
  }
}
