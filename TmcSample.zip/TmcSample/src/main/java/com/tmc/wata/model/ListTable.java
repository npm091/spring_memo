package com.tmc.wata.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ListTable implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 1L;

  private String jiki;

  private String kenmei;

  private String bukyoku;

  private String kasyo;

  private String gyoshu;

  private String biko;
}
