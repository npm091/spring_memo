package com.tmc.wata.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.tmc.wata.model.ListApi;
import com.tmc.wata.model.ListTable;
import com.tmc.wata.model.RegisterForm;
import com.tmc.wata.service.ListService;

@Controller
public class RegisterController
{
  /** sl4j logger */
  Logger logger = LoggerFactory.getLogger(RegisterController.class);

  @Autowired
  private ListService service;

  /**
   * init - 画面の初期化
   *
   * @param model
   * @return
   */
  @RequestMapping(value = "/register", method = RequestMethod.GET)
  public String init(
      Model model,
      @RequestParam("nendo") String nendo,
      @RequestParam("chotatsuKbnNo") String chotatsuKbnNo) {
    RegisterForm form = new RegisterForm();

    if (null != nendo) {
      form.setNendo(nendo);
    }
    if (null != chotatsuKbnNo) {
      form.setChotatsuKbnNo(chotatsuKbnNo);
    }
    service.setupRegisterForm(form);
    model.addAttribute("RegisterForm", form);

    return "register";
  }

  /**
   * setup form - 全てのリクエストの前に実行される
   *
   * @param oldform
   * @return
   */
  @ModelAttribute("RegisterForm")
  public RegisterForm setUpRegister(
      Model model,
      @ModelAttribute RegisterForm form) {
    RegisterForm newform = new RegisterForm();
    BeanUtils.copyProperties(form, newform);
    service.setupRegisterForm(newform);
    return newform;
  }

  /**
   * save data - 「保存」ボタンが押下されたときに実行
   *
   * @param model
   * @param form
   * @return
   */
  @RequestMapping(value = "/register", params = "btnSave", method = RequestMethod.POST)
  public String savedata(
      Model model,
      @ModelAttribute RegisterForm form) {
    logger.info("form.nendo={}", form.getNendo());
    logger.info("form.chotatsuKbnNo={}", form.getChotatsuKbnNo());
    logger.info("form.jiki={}", form.getJiki());
    logger.info("form.kenmei={}", form.getKenmei());
    logger.info("form.biko={}", form.getBiko());
    return "register";
  }

  /**
   * save data -  - 「保存(Ajax)」ボタンが押下されたときに実行
   *
   * @param reqJson
   * @param form
   * @return
   */
  @ResponseBody
  @RequestMapping(value = "/register", method = RequestMethod.POST,
  consumes = MediaType.APPLICATION_JSON_VALUE, produces = "text/plain;charset=UTF-8")
  public String savedata(
      @RequestBody String reqJson,
      @ModelAttribute RegisterForm form) {
    Gson gson = new Gson();
    ListApi req = gson.fromJson(reqJson, ListApi.class);
    logger.info("req.nendo={}", req.getNendo());
    logger.info("req.chotatsuKbnNo={}", req.getChotatsuKbnNo());
    logger.info("req.jiki={}", req.getJiki());
    logger.info("req.kenmei={}", req.getKenmei());
    logger.info("req.biko={}", req.getBiko());
    List<ListTable> list = service.getTableList(req.getNendo(), req.getChotatsuKbnNo());
    String result = gson.toJson(list);
    return result;
  }
}
