package com.tmc.wata.service;

import java.util.Map;

public class Utils
{
  /**
   * Mapの先頭のキーを返す
   *
   * @param map
   * @return
   */
  public static String getMapFKey(Map<String, String> map) {
    for (String key : map.keySet()) {
      return key;
    }
    return null;
  }

  /**
   * Mapの指定した順番のキーを返す
   *
   * @param map
   * @param ns
   * @return
   */
  public static String getMapSKey(Map<String, String> map, int n) {
    int i = 0;
    for (String key : map.keySet()) {
      if (i == n) {
        return key;
      }
      i++;
    }
    return null;
  }
}
