package com.tmc.wata.model;

import java.io.Serializable;
import java.util.Map;

import lombok.Data;

@Data
public class Selector implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 1L;

  private String nendo;

  private String chotatsuKbnNo;

  private String bukyokuNo;

  private String kashoNo;

  private String gyoshuNo;

  private Map<String, String> nendoList;

  private Map<String, String> chotatsuKbnList;

  private Map<String, String> bukyokuList;

  private Map<String, String> kashoList;

  private Map<String, String> gyoshuList;

}
