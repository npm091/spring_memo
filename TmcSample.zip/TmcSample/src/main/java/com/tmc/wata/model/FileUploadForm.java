package com.tmc.wata.model;

import javax.validation.constraints.NotNull;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

/**
 *
 * @author TMC
 *
 */
@Data
public class FileUploadForm {
    @NotNull
    private MultipartFile uploadFile;
}
