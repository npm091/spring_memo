package com.tmc.wata.controller;

import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.ServletException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.tmc.wata.model.TmcSampleApi;
import com.tmc.wata.model.TmcSampleForm;

/**
 * Account Management Controller
 *
 * @author r10523
 *
 */
@Controller
public class TmcSampleController
{
  /** sl4j logger */
  Logger logger = LoggerFactory.getLogger(TmcSampleController.class);

  /**
   * setup form - @ModelAttributeにより全てのリクエストの前に実行される
   *
   * @param model
   * @return
   */
  @ModelAttribute("tmcSampleForm")
  public TmcSampleForm setupForm(
      Model model,
      @ModelAttribute("tmcSampleForm") TmcSampleForm form) {
    return new TmcSampleForm();
  }

  /**
   * initialize screen
   *
   * @param model
   * @return
   */
  @RequestMapping(value = "/tmcSample", method = RequestMethod.GET)
  public String init(
      Model model) {
    logger.info("init()");
    TmcSampleForm form = setupHome(new TmcSampleForm(), true);
    model.addAttribute("tmcSampleForm", form);
    return "tmcSample";
  }

  /**
   * selected Shobun (submmit)
   *
   * @param model
   * @param form
   * @return
   */
  @RequestMapping(value = "/tmcSample", params = "selectedShobun", method = RequestMethod.POST)
  public String selectedShobun(
      Model model,
      @ModelAttribute("tmcSampleForm") TmcSampleForm form) {
    logger.info("form.shobun:" + form.getSelectedShobun());

    TmcSampleForm newform = new TmcSampleForm();
    BeanUtils.copyProperties(form, newform);
    form = setupHome(newform, false);
    if (form.getSelectedShobun() == 0) {
      for (int i = 0; i < form.getActivates().length; i++) {
        form.getActivates()[i] = false;
      }
    } else if (form.getSelectedShobun() == 1) {
      form.getActivates()[0] = true;
    } else if (form.getSelectedShobun() == 2) {
      form.getActivates()[1] = true;
    } else if (form.getSelectedShobun() == 3) {
      form.getActivates()[2] = true;
    } else if (form.getSelectedShobun() == 4) {
      form.getActivates()[3] = true;
    }
    model.addAttribute("tmcSampleForm", form);
    return "tmcSample";
  }

  /**
   * selected Shobun (Ajax)
   * @param req
   * @return
   * @throws IOException
   * @throws ServletException
   */
  @ResponseBody
  @RequestMapping(value = "/selectUpdate", method = RequestMethod.POST,
    produces = MediaType.APPLICATION_JSON_VALUE)
  public String selectedShobunAjax(
      @Validated TmcSampleApi req)
      throws IOException, ServletException {
    logger.info("request.mode:" + req.getMode());
    logger.info("request.shobun:" + req.getShobun());
    return req.getShobun();
  }

  /**
   * Setup initial screen
   *
   * @param form TmcSampleForm
   * @return TmcSampleForm
   */
  public TmcSampleForm setupHome(TmcSampleForm form, Boolean initialFlag) {
    if (initialFlag) {
      for (int i = 0; i < form.getActivates().length; i++) {
        form.getActivates()[i] = false;
      }
    }

    Map<Integer, String> nendoList = new TreeMap<Integer, String>();
    nendoList.put(2016, "平成28年度");
    nendoList.put(2017, "平成29年度");
    nendoList.put(2018, "平成30年度");
    form.setNendoList(nendoList);

    Map<Integer, String> gyomuList = new TreeMap<Integer, String>();
    gyomuList.put(1, "業務1");
    gyomuList.put(2, "業務2");
    gyomuList.put(3, "業務3");
    form.setGyomuList(gyomuList);

    Map<Integer, String> shobunList = new TreeMap<Integer, String>();
    shobunList.put(0, "処分0");
    shobunList.put(1, "処分1");
    shobunList.put(2, "処分2");
    shobunList.put(3, "処分3");
    shobunList.put(4, "処分4");
    form.setShobunList(shobunList);
    logger.info("setupForm()");
    return form;
  }
}
