package com.tmc.wata.model;

import java.util.Map;

import lombok.Data;

@Data
public class TmcSampleForm
{
  /** Nendo */
  private Integer selectedNendo;

  /** Nendo list */
  private Map<Integer, String> nendoList;

  /** Gyomu */
  private Integer selectedGyomu;

  /** Gyomu list */
  private Map<Integer, String> gyomuList;

  /** Shobun */
  private Integer selectedShobun;

  /** Shobun list */
  private Map<Integer, String> ShobunList;

  /** GyoshaNo */
  private String gyoshaNo;

  /** Meisho */
  private String meisho;

  private Boolean[] activates = new Boolean[4];

}
