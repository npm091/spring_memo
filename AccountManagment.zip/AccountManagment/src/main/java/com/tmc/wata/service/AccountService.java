package com.tmc.wata.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.ibatis.session.RowBounds;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tmc.wata.db.entity.Users;
import com.tmc.wata.db.entity.UsersBean;
import com.tmc.wata.db.entity.UsersExample;
import com.tmc.wata.db.mapper.UsersMapper;
import com.tmc.wata.db.mappercustom.UsersMapperCustom;
import com.tmc.wata.model.AccountForm;

@Service
public class AccountService
{
  private static final Logger logger = LoggerFactory.getLogger(AccountService.class);

  @Autowired
  UsersMapper usersMapper;

  @Autowired
  UsersMapperCustom usersMapperCustom;

  /** order by list */
  static final List<String> sortByList = Arrays.asList("ID", "Account", "Email");
  static final List<String> ordertByList = Arrays.asList("id", "name", "email");

  /** direction list of order by*/
  static final List<String> sortDirectionList = Arrays.asList("ASC", "DESC");

  /** row bounds list */
  static final List<Integer> rowBoundsList = Arrays.asList(2, 5, 10, 20, 50);

  /**
   * setup select options and default choices
   *
   * @param form
   * @return
   */
  public AccountForm setupSelectOptions(AccountForm form) {
    logger.info("setupSelectOptions()");
    if (null == form) {
      form = new AccountForm();
    }

    /** Select options of Sort by */
    Map<Integer, String> map1 = new TreeMap<Integer, String>();
    for (String item : sortByList) {
      int idx = sortByList.indexOf(item);
      map1.put(idx, item);
    }
    form.setSortList(map1);
    // setup default if null, when initial display
    // otherwise it means when search button is pressed
    if (null == form.getSelectedSortBy()) {
      form.setSelectedSortBy(0);
    }

    /** Select options of sort direction */
    Map<Integer, String> map2 = new TreeMap<Integer, String>();
    for (String item : sortDirectionList) {
      int idx = sortDirectionList.indexOf(item);
      map2.put(idx, item);
    }
    form.setSortDirectionList(map2);
    // setup default if null, when initial display
    // otherwise it means when search button is pressed
    if (null == form.getSelectedDirection()) {
      form.setSelectedDirection(0);
    }

    /** Select options of row bounds */
    Map<Integer, Integer> map3 = new TreeMap<Integer, Integer>();
    for (Integer item : rowBoundsList) {
      int idx = rowBoundsList.indexOf(item);
      map3.put(idx, item);
    }
    form.setRowBoundsList(map3);
    // setup default if null, when initial display
    // otherwise it means when search button is pressed
    if (null == form.getSelectedRowBounds()) {
      form.setSelectedRowBounds(0);
    }

    // current page number
    UsersExample ex = new UsersExample();
    int count = usersMapper.countByExample(ex);
    form.setMaxCount(count);
    if (null == form.getPageNo()) {
      form.setPageNo(0);
      form.setPageNoStr("");
    } else {
      int maxPage = count / rowBoundsList.get(form.getSelectedRowBounds());
      if ((count % rowBoundsList.get(form.getSelectedRowBounds())) != 0) {
        maxPage = maxPage + 1;
      }
      form.setMaxPageNo(maxPage);
    }
    return form;
  }

  /**
   * get user account list from database (custom)
   *
   * @return user account list
   */
  public List<UsersBean> getUserListCustom(AccountForm form, int page) {
    logger.info("getUserListCustom()");

    // set to current page
    form.setPageNo(page);
    String msg = String.format("Page %d of %d", form.getPageNo() + 1, form.getMaxPageNo());
    form.setPageNoStr(msg);

    // setup order by clause
    int idx = form.getSelectedSortBy();
    String orderBy = ordertByList.get(idx);

    // setup order direction
    idx = form.getSelectedDirection();
    String direction = sortDirectionList.get(idx);
    String orderClause = orderBy + " " + direction;

    // setup rowbounds
    idx = form.getSelectedRowBounds();
    int limit = rowBoundsList.get(idx);
    int offset = page * limit;
    RowBounds rowBounds = new RowBounds(offset, limit);

    List<UsersBean> userList = usersMapperCustom.selectByExample(rowBounds, orderClause);
    return userList;
  }

  /**
   * get user account list from database (default mybatis setting)
   *
   * @return user account list
   */
  public List<UsersBean> getUserList() {
    logger.info("getUserList()");
    List<UsersBean> userBeanList = new ArrayList<UsersBean>();
    UsersExample ex = new UsersExample();
    ex.setOrderByClause("id");
    List<Users> userList = usersMapper.selectByExample(ex);

    for (Users user : userList) {
      UsersBean bean = new UsersBean();
      bean.setId(user.getId());
      bean.setName(user.getName());
      bean.setEmail(user.getEmail());
      userBeanList.add(bean);
    }
    return userBeanList;
  }

  /**
   * get user account list from database (for test)
   *
   * @return user account list
   */
  public Map<String, UsersBean> getUserMap() {
    logger.info("getUserMap()");
    Map<String, UsersBean> userBeanMap= new TreeMap<String, UsersBean>();
    UsersExample ex = new UsersExample();
    ex.setOrderByClause("id");
    List<Users> userList = usersMapper.selectByExample(ex);

    for (Users user : userList) {
      UsersBean bean = new UsersBean();
      bean.setName(user.getName());
      bean.setEmail(user.getEmail());
      userBeanMap.put(String.valueOf(user.getId()), bean);
    }
    return userBeanMap;
  }
}
