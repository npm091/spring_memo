package com.tmc.wata.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.tmc.wata.db.entity.UsersBean;
import com.tmc.wata.model.AccountForm;
import com.tmc.wata.service.AccountService;

/**
 * Account Management Controller
 *
 * @author r10523
 *
 */
@Controller
public class AccountController
{
  /** sl4j logger */
  Logger logger = LoggerFactory.getLogger(AccountController.class);
  private static int counter = 0;
  @Autowired
  private AccountService accountService;

  /**
   * setup form - @ModelAttributeにより全てのリクエストの前に実行される
   *
   * @param model
   * @return
   */
  @ModelAttribute("accountForm")
  public AccountForm setupForm(
      Model model,
      @ModelAttribute("accountForm") AccountForm form) {
    logger.info("setupForm()");
    // setup select options
    accountService.setupSelectOptions(form);
    return form;
  }

  /**
   * initialize screen
   *
   * @param model
   * @return
   */
  @RequestMapping(value = "/accountHome", method = RequestMethod.GET)
  public String init(
      Model model) {
    logger.info("init()");
    AccountForm form = accountService.setupSelectOptions(null);
    model.addAttribute("accountForm", form);
    return "accountHome";
  }

  /**
   * search - "search" button pressed
   *
   * @param model
   * @param form
   * @return
   */
  @RequestMapping(value = "/accountHome", params = "btnSearch", method = RequestMethod.POST)
  public ModelAndView search(
      ModelAndView mv,
      @ModelAttribute("accountForm") AccountForm form) {
    logger.info("search(): {}/{}", form.getPageNo(), form.getMaxPageNo());
    int pageno = form.getPageNo();
    List<UsersBean> list = accountService.getUserListCustom(form, pageno);
    form.setUserList(list);
    /** toggle */
    boolean flg = ((counter++ % 2) == 0) ? true : false;
    logger.info("btnActivate1:{}, counter={}", flg, counter);
    form.setBtnActivate(flg);
    mv.addObject("userList", form.getUserList());
    return mv;
  }

  /**
   * search - "previous" button pressed
   *
   * @param model
   * @param form
   * @return
   */
  @RequestMapping(value = "/accountHome", params = "btnPrevious", method = RequestMethod.POST)
  public ModelAndView previous(
      ModelAndView mv,
      @ModelAttribute("accountForm") AccountForm form) {
    logger.info("previous(): {}/{}", form.getPageNo(), form.getMaxPageNo());
    int pageno = form.getPageNo();
    if (pageno > 0) {
      pageno = pageno - 1;
    }
    List<UsersBean> list = accountService.getUserListCustom(form, pageno);
    form.setUserList(list);
    mv.addObject("userList", form.getUserList());
    return mv;
  }

  /**
   * search - "next" button pressed
   *
   * @param model
   * @param form
   * @return
   */
  @RequestMapping(value = "/accountHome", params = "btnNext", method = RequestMethod.POST)
  public ModelAndView next(
      ModelAndView mv,
      @ModelAttribute("accountForm") AccountForm form) {
    logger.info("next(): {}/{}", form.getPageNo(), form.getMaxPageNo());
    int pageno = form.getPageNo();
    if (pageno < (form.getMaxPageNo()-1)) {
      pageno = pageno + 1;
    }
    List<UsersBean> list = accountService.getUserListCustom(form, pageno);
    form.setUserList(list);
    mv.addObject("userList", form.getUserList());
    return mv;
  }

  /**
   * yyyymmdd - 年月日時分秒の文字列
   *
   * @return
   */
  public String yyyymmddhhss() {
    Date dt = new Date();
    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmss");
    return sdf.format(dt);
  }
}
