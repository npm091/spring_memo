package com.tmc.wata.model;

import java.util.List;
import java.util.Map;

import com.tmc.wata.db.entity.UsersBean;

import lombok.Data;

@Data
public class AccountForm
{
  /** selected sort by */
  private Integer selectedSortBy;

  /** options of sort by */
  private Map<Integer, String> sortList;

  /** selected direction of sort */
  private Integer selectedDirection;

  /** sort direction list */
  private Map<Integer, String> sortDirectionList;

  /** selected row baounds */
  private Integer selectedRowBounds;

  /** row baounds list */
  private Map<Integer, Integer> rowBoundsList;

  /** user account list */
  private List<UsersBean> userList;

  /** current page number */
  private Integer pageNo;

  /** current page number for display */
  private String pageNoStr;

  /** data count */
  private Integer maxCount;

  /** max page number */
  private Integer maxPageNo;
}
