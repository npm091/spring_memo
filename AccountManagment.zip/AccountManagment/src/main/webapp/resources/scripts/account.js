$(function() {
  tr_default("#dataTable");
  $("#dataTable tr").click(function() {
    tr_default("#dataTable");
    tr_click($(this));
  });
  $("#dataTable td").click(function() {
    $tag_tr = $(this).parent()[0];
    console.log("%s行", $tag_tr.rowIndex);
  });

});

function tr_default(tblID) {
  var vTR = tblID + " tr";
  $(vTR).not("th").css("background-color", "#ffffff");
  $(vTR).mouseover(function() {
    $(this).not("th").css("background-color", "#CCFFCC").css("cursor", "pointer");
  });
  $(vTR).mouseout(function() {
    $(this).not("th").css("background-color", "#ffffff").css("cursor", "normal");
  });
}

function tr_click(trID) {
  trID.not("th").css("background-color", "#e49e61");
  trID.mouseover(function() {
    $(this).not("th").css("background-color", "#CCFFCC").css("cursor", "pointer");
  });
  trID.mouseout(function() {
    $(this).not("th").css("background-color", "#e49e61").css("cursor", "normal");
  });
}

function selectUpdateSubmit(mode) {

  // 
  $('<input>').attr({
      type: 'hidden',
      id: 'selectedShobun',
      name: 'selectedShobun', 
      value: 'temporary'
  }).appendTo('.mainTable');

  $('#tmcForm').submit();
}

function selectUpdateAjax(mode) {
  var req = {
      mode : mode,
      shobun: $("#selectedShobun").val()
  };

  $.ajax({
    type: 'POST',
    url: '/selectedShobunAjax',
    data: req,
    async: false,
    dataType: 'json'
  }).done(function(data, textStatus, jqXHR) {
      console.log(data);
  }).fail(function(jqXHR, textStatus, errorThrown) {
      console.log(jqXHR);
  }).always(function(jqXHR, textStatus) {
    // nothing to do
  });
}
