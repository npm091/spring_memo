	var form = null;

	function showCreateConfirm(val)
	{
		cloneForm('create');
		appendMainButtons('create');
		$("html, body", parent.window.document).scrollTop(0);
	}

	function showEditConfirm(val)
	{
		cloneForm('edit');
		cloneTargetTableRow(val);

		$(".clone input[type='button']").parent().hide();
		appendMainButtons('edit');
		$("html, body", parent.window.document).scrollTop(0);
	}

	function showDelConfirm(val)
	{
		cloneForm('delete');
		cloneTargetTableRow(val);

		$(".clone input[type='button']").parent().hide();
		appendMainButtons('delete');
		$("html, body", parent.window.document).scrollTop(0);
	}

	function cloneForm(val)
	{
		form = $("." + val + "_form").clone();
		form.clone().addClass("clone").addClass("form_clone").insertAfter("#loadingScreen").css("top", "80").css("display", "block");
		$('.form_clone').attr('action', $('.form_clone').attr('action') + val);

		$("#loadingScreen").css("height", Math.max.apply(null, [document.body.clientHeight , document.body.scrollHeight, document.documentElement.scrollHeight, document.documentElement.clientHeight])).show();
		$("#loadingScreen img").hide();
		$("#main_message").clone().addClass("clone").insertAfter("#loadingScreen").css("margin", "5%").css("display", "block");

		$(".form_clone").css("z-index", 1003);
	}

	function cloneTargetTableRow(val)
	{
		var tr = $(val).closest('tr').clone();
		$('.form_clone').find('tbody tr').html($(tr).html());
		$('.form_clone a').each(function() {
			$(this).replaceWith('<span>' + $(this).text() + '</span>')
		});
		$('.form_clone').append('<input type="hidden" name="key" value = "' + $(tr).find('.key').val() + '" />');
	}

	function appendMainButtons(val)
	{
		var submitText = ('delete' == val)? 'OK' : '設定';
		$(".form_clone .main_buttons").append('<input type="submit" value=' + submitText + ' class="exec_button" /> &nbsp;');
		$(".form_clone .main_buttons").append('<input type="button" value="キャンセル" class="back_button close_sub" />');
		$(".clone .back_button").click(back2Edit);
	}

	//
	function initActionButtons(){
		$(".create_button").each(function()
		{
			$(this).click(function()
			{
				showCreateConfirm(this);
			});
		});
		$(".edit_button").each(function()
		{
			$(this).click(function()
			{
				showEditConfirm(this);
			});
		});
		$(".delete_button").each(function()
		{
			$(this).click(function()
			{
				showDelConfirm(this);
			});
		});

	}
