package com.tmc.wata.db.mappercustom;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import com.tmc.wata.db.entity.UsersBean;

public interface UsersMapperCustom
{
  /**
   * select user account list with oder by
   * 
   * @param orderByClause
   * @return
   */
  List<UsersBean> selectByExample(
    RowBounds rowBounds,
    @Param("orderByClause") String orderByClause);
}