//=============================================================================
// 共通スクリプト（グローバル定義）
//=============================================================================
//
function toggleResize(flg)
{
	// 0番目はflg、1番目からtoggle
	for (var i = 1; i < arguments.length; i++)
	{
		$(arguments[i]).toggle(flg);
	}
	resizePopup();
}
//
function resizePopup()
{
	if (parent && parent.$("#popup").length > 0)
	{
		var w = Math.max.apply(null, [parent.document.body.clientWidth - 50, 1024]);
		parent.$("#popup").css("width", w);
		parent.$("#popupTitle").css("width", w - 27);
		var h = Math.max.apply(null, [document.body.scrollHeight, 400]);
		parent.$("#popup").css("height", h + 50);
		parent.$("#popupContent").css("height", h + 23);
		parent.$("#loadingScreen").css("height", 0);
		h = Math.max.apply(null, [parent.document.body.clientHeight, parent.document.body.scrollHeight, parent.document.documentElement.scrollHeight, parent.document.documentElement.clientHeight, document.body.scrollHeight + 100]);
		parent.$("#loadingScreen").css("height", h);
	}
	$(".nDiv").height('auto').width('auto');
}
//
function back2Edit(val)
{
	$("html, body", parent.window.document).scrollTop(0);
	$("#loadingScreen").hide();
	$(".clone, .infoClone").remove();
}
// ロードイベント
$(function()
{
	// 送信前処理
	$(document).on("submit", "form", function(e)
	{
		$("select, input").each(function()
		{
			$(this).prop("disabled", false);
		});
		$("input[type='submit']").prop("disabled", true);
	});
	// メニューの OPEN/CLOSE
	$(".tab dd").hide();
	$(".tab").hover(function()
	{
		$(this).find("dd").show();
	},
	function()
	{
		$(this).find("dd").slideUp(300);
	});

	// infoメッセージ、errorメッセージをポップアップ表示
	if ($(".hasInfo").text() || $(".hasError").text()) {
		$(function() {
			$("#message").clone().addClass("clone").addClass("infoClone").insertAfter("#loadingScreen").css("top", "80").show("fast");
			$("#loadingScreen").css("height", Math.max.apply(null, [document.body.clientHeight , document.body.scrollHeight, document.documentElement.scrollHeight, document.documentElement.clientHeight])).show();
			$("#loadingScreen img").hide();
			$(".clone").css("z-index", 1003);

			$(".clone").append('<p><input type="button" value="戻る" class="back_button" /></p>');
			$(".clone .back_button").click(back2Edit);
			$("html, body", parent.window.document).scrollTop(0);
		});
	}


	// ポップアップ
	var isMouseDown = false;
	var popupX = 0, popupY = 0;
	var mouseX = 0, mouseY = 0;

	$(document).on("click", ".popup_link", function(e)
	{
		if (parent && parent.$("#popup").length > 0)
		{
			return true;
		}
		$('body').append(
			'<div id="popup">' +
			'	<div id="popupBar"><div id="popupTitle"></div><div id="popupClose" class="popupCloseMouseUp close_sub">×</div></div>' +
			'	<iframe id="popupContent" src="' + $(this).attr('href') + '"></iframe>' +
			'</div>' +
			'<div id="popupHandle"></div>'
		);
		popupX = 20;
		popupY = 20;
		$('#popup').css({'left': popupX, 'top': popupY});
		$('#popupHandle').hide();
		$('.close_sub')
			.bind('mousedown', function(e)
			{
				$(this).removeClass("popupCloseMouseUp").addClass("popupCloseMouseDown");
			})
			.bind('mouseout', function(e)
			{
				$(this).removeClass("popupCloseMouseDown").addClass("popupCloseMouseUp");
			})
			.bind('mouseup', function(e)
			{
				$(".reload_button").click();
				$(".close_sub").click();
				$("#popup").remove();
				$("#popupHandle").remove();
				$("#loadingScreen").hide();
			})
			.bind('selectstart', function(e)
			{
				return false;
			});
		$('#popupTitle')
			.bind('mousedown', function(e)
			{
				mouseX = e.pageX;
				mouseY = e.pageY;
				isMouseDown = true;
				$('#popupHandle').show();
			})
			.bind('selectstart', function(e)
			{
				return false;
			});
		$(document)
			.bind('mousemove', function(e)
			{
				if(isMouseDown)
				{
					popupX = popupX + e.pageX - mouseX;
					popupY = (popupY + e.pageY - mouseY < 0) ? 0: popupY + e.pageY - mouseY;
					$('#popup').css({'left': popupX, 'top': popupY});
					mouseX = e.pageX;
					mouseY = (e.pageY < 0) ? 0 : e.pageY;
				}
			})
			.bind('mouseup', function(e)
			{
				if(isMouseDown)
				{
					isMouseDown = false;
					$('#popupHandle').hide();
				}
			});
	////////////////////////////
		$("#loadingScreen").css("height", Math.max.apply(null, [document.body.clientHeight, document.body.scrollHeight, document.documentElement.scrollHeight, document.documentElement.clientHeight])).show();
		$("#loadingScreen img").hide();
		return false;
	});
	//
	if (parent && parent.$("#popup").length > 0)
	{
		//
		if($(".main_buttons").length == 0)
		{
			$("#main").append('<div class="main_buttons"></div>');
		}
		$(".main_buttons").append(' <input type="button" value="閉じる" class="close_sub" />');
		$(document).on("click", ".close_button", function(e)
		{
			parent.$('#popupClose').mouseup();
		});
		//
		$("#header").hide();
		$("#footer").hide();
		resizePopup();
		$("html, body", parent.window.document).scrollTop(0);
	}
	$("#loadingScreen").hide();
});
