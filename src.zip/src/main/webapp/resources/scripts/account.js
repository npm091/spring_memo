$(function() {
  tr_default("#dataTable");
  $("#dataTable tr").click(function() {
    tr_default("#dataTable");
    tr_click($(this));
  });
  $("#dataTable td").click(function() {
    $tag_tr = $(this).parent()[0];
    console.log("%s行", $tag_tr.rowIndex);
  });

});

function tr_default(tblID) {
  var vTR = tblID + " tr";
  $(vTR).not("th").css("background-color", "#ffffff");
  $(vTR).mouseover(function() {
    $(this).not("th").css("background-color", "#CCFFCC").css("cursor", "pointer");
  });
  $(vTR).mouseout(function() {
    $(this).not("th").css("background-color", "#ffffff").css("cursor", "normal");
  });
}

function tr_click(trID) {
  trID.not("th").css("background-color", "#e49e61");
  trID.mouseover(function() {
    $(this).not("th").css("background-color", "#CCFFCC").css("cursor", "pointer");
  });
  trID.mouseout(function() {
    $(this).not("th").css("background-color", "#e49e61").css("cursor", "normal");
  });
}