package com.tmc.wata.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class Bukyoku implements Serializable {
  /**
   * 
   */
  private static final long serialVersionUID = 1L;
  
  private String mode;
  private String nendo;
  private String chotatsu;

}
