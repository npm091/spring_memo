package com.tmc.wata.model;

import java.util.Date;

import lombok.Data;

@Data
public class User
{

  private String userid;

  private String password;

  private Integer privilege;

  private String wardcode;

  private Integer isdeleted;

  private Date createdatetime;
}
