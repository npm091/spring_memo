package com.tmc.wata;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.tmc.wata.model.User;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController
{
  /**
   * Simply selects the home view to render by returning its name.
   */
  private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

  @RequestMapping(value = "/", method = RequestMethod.GET)
  public String home(Locale locale, Model model) {

    Date date = new Date();
    DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
    String formattedDate = dateFormat.format(date);
    model.addAttribute("serverTime", formattedDate);

    logger.info("formattedDate is {}.", formattedDate);

    return "home";
  }

  @RequestMapping(value = "/select", method = RequestMethod.GET)
  public String seltest1(Locale locale, Model model) {

    return "seltest1";
  }


  @RequestMapping(value = "/system", method = RequestMethod.GET)
  public String system(Locale locale, Model model) {
    model.addAttribute("user", setupUser("001", 2));
    model.addAttribute("allUsers", getAUserList());
    model.addAttribute("wardcodeList", new TreeMap<String, String>());
    model.addAttribute("targetUser", "001");

    return "accountList";
  }

  @RequestMapping(value = "/system/account/data", method = RequestMethod.GET)
  public ModelAndView getListAccountData(ModelAndView mv) {
    List<User> users = getAUserList();
    mv.addObject("user", setupUser("001", 2));
    mv.addObject("allUsers", users);
    mv.setViewName("fragments/account :: list");
    return mv;
  }

  private List<User> getAUserList() {
    List<User> list = new ArrayList<User>();
    
    list.add(setupUser("001", 1));
    list.add(setupUser("002", 1));
    return list;
  }

  private User setupUser(String userid, Integer privilege ) {
    User user = new User();
    user.setUserid(userid);
    user.setPassword("");
    user.setPrivilege(privilege);
    return user;
  }

}