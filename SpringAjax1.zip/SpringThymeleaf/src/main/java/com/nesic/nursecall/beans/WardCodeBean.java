package com.nesic.nursecall.beans;

import java.util.TreeMap;

import org.springframework.stereotype.Component;

import lombok.NoArgsConstructor;

@Component
@NoArgsConstructor
public class WardCodeBean {

    /** WardCode & WardName Mapping */
    static private TreeMap<String, String> wardCodeMap = null;

    /**
     * getWardCdMap
     * 説明 病棟コード・病棟名マップを取得する。
     * @return TreeMap<String, String> 病棟コード・病棟名マップ
     */
    public TreeMap<String, String> getWardCdMap() {
        return new TreeMap<String, String>();
    }

    /**
     * getWardName
     * 説明 病棟名を取得する。
     * @return String 病棟名
     */
    public String getWardName(String wardCode) {
        getWardCdMap();
        return wardCodeMap.get(wardCode);
    }

}
