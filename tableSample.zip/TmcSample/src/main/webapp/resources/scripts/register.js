// call when form invocation
$(document).ready(function() {
  // console.log('hidden.nendo=' + document.getElementById("hNendo").value);
  // console.log('hidden.chotatsuKbnNo=' + document.getElementById("hChotatsuKbnNo").value);
});

function saveData() {
  // request parameter
  var request = {
    nendo: "",
    chotatsuKbnNo: "",
    jiki: "",
    kenmei: "",
    biko: ""
  };
  var nendo = document.getElementById("nendo").value;
  var chotatsuKbnNo = document.getElementById("chotatsuKbnNo").value;
  var jiki = document.getElementById("jiki").value;
  var kenmei = document.getElementById("kenmei").value;
  var biko = document.getElementById("biko").value;
  request.nendo = nendo;
  request.chotatsuKbnNo = chotatsuKbnNo;
  request.jiki = jiki;
  request.kenmei = kenmei;
  request.biko = biko;
  console.log('nendo=' + nendo);
  console.log('chotatsuKbnNo=' + chotatsuKbnNo);
  $.ajax({
    type: "POST",
    url: "/register",
    dataType: "json",
    data: JSON.stringify(request),
    async: true,
    contentType: "application/json",
  }).done(function(data) {
    console.log("saved data successfully:" + data);
  }).fail(function(MLHttpRequest, textStatus, errorThrown) {
    console.log("Error!：" + textStatus + ":\n" + errorThrown);
  });
}

//update select options 
function createSelectists() {
  // request parameter
  var request = {
    nendo: "",
    chotatsuKbnNo: ""
  };

  var nendo = document.getElementById("nendo").value;
  var chotatsuKbnNo = document.getElementById("chotatsuKbnNo").value;
  request.nendo = nendo;
  request.chotatsuKbnNo = chotatsuKbnNo;
  console.log('nendo=' + nendo);
  console.log('chotatsuKbnNo=' + chotatsuKbnNo);
  $.ajax({
    type: "POST",
    url: "/updateSelectList",
    dataType: "json",
    data: JSON.stringify(request),
    async: true,
    contentType: "application/json",
  }).done(function(data) {
    // console.log('data.nendo=' + data.nendo);
    // console.log('data.chotatsuKbnNo=' + data.chotatsuKbnNo);
    createSelOption("bukyokuList", data.bukyokuList);
    createSelOption("kashoList", data.kashoList);
    createSelOption("gyoshuList", data.gyoshuList);
    var nendo = document.getElementById("nendo").value;
    document.getElementById("hNendo").innerHTML = data.nendo;
    document.getElementById("hChotatsuKbnNo").innerHTML = data.chotatsuKbnNo;
  }).fail(function(MLHttpRequest, textStatus, errorThrown) {
    console.log("Error!：" + textStatus + ":\n" + errorThrown);
  });
}

