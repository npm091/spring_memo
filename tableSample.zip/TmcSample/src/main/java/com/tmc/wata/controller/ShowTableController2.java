package com.tmc.wata.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.tmc.wata.model.ShowTableForm2;
import com.tmc.wata.service.ListService;

@Controller
public class ShowTableController2
{
  /** sl4j logger */
  Logger logger = LoggerFactory.getLogger(ShowTableController2.class);

  @Autowired
  private ListService service;

  /**
   * init - 画面の初期化
   *
   * @param model
   * @return
   */
  @RequestMapping(value = "/showTable2", method = RequestMethod.GET)
  public String init(
      Model model) {
    ShowTableForm2 form = new ShowTableForm2();

    model.addAttribute("ShowTableForm2", form);

    return "showTable2";
  }

  /**
   * setup form - 全てのリクエストの前に実行される
   *
   * @param oldform
   * @return
   */
  @ModelAttribute("ShowTableForm2")
  public ShowTableForm2 setUpRegister(
      Model model,
      @ModelAttribute ShowTableForm2 form) {
//    ShowTableForm2 newform = new ShowTableForm2();
//    BeanUtils.copyProperties(form, newform);
    return form;
  }

  /**
   * save data - 「保存」ボタンが押下されたときに実行
   *
   * @param model
   * @param form
   * @return
   */
  @RequestMapping(value = "/showTable2", params = "btnSave", method = RequestMethod.POST)
  public String savedata(
      Model model,
      @ModelAttribute ShowTableForm2 form) {
    logger.info("form.memo={}", form.getMemo());
    return "showTable2";
  }

 }
