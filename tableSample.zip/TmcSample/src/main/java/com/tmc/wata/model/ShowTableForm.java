package com.tmc.wata.model;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

@Data
public class ShowTableForm implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 1L;

  List<CategoryTable> categoryList;

  private String  gtotal;
}
