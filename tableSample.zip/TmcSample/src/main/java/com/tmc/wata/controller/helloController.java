package com.tmc.wata.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class helloController
{

  /** sl4j logger */
  Logger logger = LoggerFactory.getLogger(helloController.class);

  /**
   * home index
   *
   * @param model
   * @return
   */
  @RequestMapping(value = "/hello", method = RequestMethod.POST)
  public String index(
      @RequestParam("name") String name,
      Model model) {
    System.out.println("name: " + name);
    model.addAttribute("name", "Tmc");
    return "hello";
  }
}
