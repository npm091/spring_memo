package com.tmc.wata.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.tmc.wata.model.FileUploadForm;
import com.tmc.wata.model.RegisterForm;
import com.tmc.wata.model.RegisterTable;
import com.tmc.wata.model.RequestApi;
import com.tmc.wata.service.RegisterService;
import com.tmc.wata.service.Utils;

/**
 * Handles requests for the application home page.
 */
@Controller
public class RegisterController
{
  /** sl4j logger */
  Logger logger = LoggerFactory.getLogger(RegisterController.class);

  @Autowired
  private RegisterService service;

  @Autowired
  ResourceLoader resourceLoader;

  private static final String UPLOAD_DIR = "D:/usr/tmp/";
  /**
   * Call when Controller initialization
   */
  @PostConstruct
  public RegisterForm init() {
    RegisterForm form = new RegisterForm();
    return form;
  }

  /**
   * setup form
   *
   * @return Form class
   */
  @ModelAttribute
  public RegisterForm setUpRegisterForm() {
    RegisterForm form = new RegisterForm();

    Map<String, String> nendoList = service.getNendoList();
    form.setNendoList(nendoList);

    Map<String, String> chotatsuKbnList = service.getChotatsuKbnList();
    form.setChotatsuKbnList(chotatsuKbnList);

    String nendo = Utils.getMapFKey(nendoList);
    String chotatsuKbNo = Utils.getMapFKey(chotatsuKbnList);

    Map<String, String> bukyokuList = service.getBukyokuList(nendo, chotatsuKbNo);
    form.setBukyokuList(bukyokuList);

    Map<String, String> kashoList = service.getKashoList(nendo, chotatsuKbNo);
    form.setKashoList(kashoList);

    Map<String, String> gyoshuList = service.getGyoshuList(nendo, chotatsuKbNo);
    form.setGyoshuList(gyoshuList);
    return form;
  }

  /**
   * register get method
   *
   * @param model
   * @return
   */
  @RequestMapping(value = "/register", method = RequestMethod.GET)
  public String registerGet(Model model, @ModelAttribute RegisterForm form) {
    model.addAttribute("RegisterForm", form);
    return "register";
  }

  /**
   * register post method
   *
   * @param model
   * @return
   */
  @RequestMapping(value = "/register", method = RequestMethod.POST)
  public ModelAndView registerPost(
      @ModelAttribute RegisterForm form, // form parameter
      @RequestParam("action") String action, // request parameter
      ModelAndView mav, // model and view
      BindingResult result, // binding result
      SessionStatus session // session
  ) {
    logger.info("action:{}", action);
//    logger.info("nendo={}", nendo);
//    logger.info("chotatsuKbnNo={}", chotatsuKbnNo);
    mav.addObject("RegisterForm", form);
    return mav;
  }

  /**
   * update select options
   *
   * @param model
   * @return
   */
  @ResponseBody
  @RequestMapping(value = "/updateSelectList", method = RequestMethod.POST,
  consumes = MediaType.APPLICATION_JSON_VALUE, produces = "text/plain;charset=UTF-8")
//    headers = {"content-type=*", "accept=application/json"})
  public String updateSelectListPost(@RequestBody String reqJson) {
    Gson gson = new Gson();
    RequestApi req = gson.fromJson(reqJson, RequestApi.class);
    logger.info("req.nendo={}", req.getNendo());
    logger.info("req.chotatsuKbnNo={}", req.getChotatsuKbnNo());
    RequestApi res = service.getSelectList(req.getNendo(), req.getChotatsuKbnNo());
    String result = gson.toJson(res);
    return result;
  }

  /**
   * search data
   *
   * @param model
   * @return
   */
  @ResponseBody
  @RequestMapping(value = "/searchData", method = RequestMethod.POST,
    consumes = MediaType.APPLICATION_JSON_VALUE,
    produces = "text/plain;charset=UTF-8")
//    headers = {"content-type=*", "accept=application/json"})
  public String search(@RequestBody String reqJson) {
    Gson gson = new Gson();
    RequestApi req = gson.fromJson(reqJson, RequestApi.class);
    logger.info("req.nendo={}", req.getNendo());
    logger.info("req.chotatsuKbnNo={}", req.getChotatsuKbnNo());
    List<RegisterTable> list = service.getTableList(req.getNendo(), req.getChotatsuKbnNo());
    String result = gson.toJson(list);
    return result;
  }

  /**
   * file download & upload
   *
   * @param model
   * @return
   */
  @RequestMapping(value = "/fdownload", method = RequestMethod.POST)
  public ResponseEntity<byte[]> download(@ModelAttribute RegisterForm form)
      throws IOException {
    HttpHeaders h = new HttpHeaders();
    String filePath = form.getNendo() + form.getChotatsuKbnNo() + ".csv";
    h.add("Content-Type", "text/csv; charset=Shift_JIS");
    h.setContentDispositionFormData("filename", filePath);
    String buff = service.getTableData(form.getNendo(), form.getChotatsuKbnNo());
    return new ResponseEntity<>(buff.getBytes("Shift_JIS"), h, HttpStatus.OK);
  }

  @RequestMapping(value = "/fupload", method = RequestMethod.GET)
  public ModelAndView fileUpload(@ModelAttribute FileUploadForm form) {
    ModelAndView mv = new ModelAndView("fupload");
    return mv;
  }

  @RequestMapping(value = "/fupload", method = RequestMethod.POST)
  public String fileUploadComplete(
      Model model,
      @ModelAttribute RegisterForm form,
      @RequestParam("FileUploadForm") MultipartFile file) {
    model.addAttribute("RegisterForm", form);

    String loadfile = file.getOriginalFilename();
    logger.info("loadfile={}", loadfile);
    if (null == loadfile || "".equals(loadfile)) {
      return "register";
    }
    String saveFile = UPLOAD_DIR + file.getName() + yyyymmddhhss() + ".csv";
    logger.info("savefile={}", saveFile);
    byte[] bytes = null;
    try {
      bytes = file.getBytes();
      BufferedOutputStream uploadFileStream =
          new BufferedOutputStream(new FileOutputStream(new File(saveFile)));
      uploadFileStream.write(bytes);
      uploadFileStream.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
    return "register";
  }

  private String yyyymmddhhss()  {
    Date dt = new Date();
    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmss");
    return sdf.format(dt);
  }
}
