// call when form invocation
$(document).ready(function() {
//  console.log('hidden.nendo=' + document.getElementById("hNendo").value);
//  console.log('hidden.chotatsuKbnNo=' + document.getElementById("hChotatsuKbnNo").value);
});

// update select options 
function createSelectists() {
  // request parameter
  var request = {
    nendo : "",
    chotatsuKbnNo : ""
  };
  var nendo = document.getElementById("nendo").value;
  var chotatsuKbnNo = document.getElementById("chotatsuKbnNo").value;
  request["nendo"] = nendo;
  request["chotatsuKbnNo"] = chotatsuKbnNo;
  console.log('nendo=' + nendo);
  console.log('chotatsuKbnNo=' + chotatsuKbnNo);
  $.ajax({
    type : "POST",
    url : "/updateSelectList",
    dataType : "json",
    data : JSON.stringify(request),
    async : true,
    contentType : "application/json",
  }).done(function(data) {
//    console.log('data.nendo=' + data.nendo);
//    console.log('data.chotatsuKbnNo=' + data.chotatsuKbnNo);
    createSelOption("bukyokuList", data.bukyokuList);
    createSelOption("kashoList", data.kashoList);
    createSelOption("gyoshuList", data.gyoshuList);
    var nendo = document.getElementById("nendo").value;
    document.getElementById("hNendo").innerHTML = data.nendo;
    document.getElementById("hChotatsuKbnNo").innerHTML = data.chotatsuKbnNo;
  }).fail(function(MLHttpRequest, textStatus, errorThrown) {
    console.log("Error!：" + textStatus + ":\n" + errorThrown);
  });
}

//search data 
function searchData() {
  // request parameter
  var request = {
    nendo : "",
    chotatsuKbnNo : ""
  };
  var nendo = document.getElementById("nendo").value;
  var chotatsuKbnNo = document.getElementById("chotatsuKbnNo").value;
  request["nendo"] = nendo;
  request["chotatsuKbnNo"] = chotatsuKbnNo;
  console.log('nendo=' + nendo);
  console.log('chotatsuKbnNo=' + chotatsuKbnNo);
  $.ajax({
    type : "POST",
    url : "/searchData",
    dataType : "json",
    data : JSON.stringify(request),
    async : true,
    contentType : "application/json",
  }).done(function(data) {
//    console.log('data=' + data);
    createTable(data);
  }).fail(function(MLHttpRequest, textStatus, errorThrown) {
    console.log("Error!：" + textStatus + ":\n" + errorThrown);
  });
}

// create data table
function createTable(data) {
  var table = document.getElementById("dataTable");

  //ヘッダ以外の行を削除
  while(table.rows[1]) table.deleteRow(1);

  //行を追加
  for (var i in data) {
    console.log("jiki:" + data[i].jiki);
    var row = table.insertRow(-1);
    addline(row, data[i]);
  }
}

//create a lien　of data table
function addline(row, line) {
  c1 = row.insertCell(-1);
  c2 = row.insertCell(-1);
  c3 = row.insertCell(-1);
  c4 = row.insertCell(-1);
  c5 = row.insertCell(-1);
  c6 = row.insertCell(-1);
  c1.innerHTML = line.jiki;
  c2.innerHTML = line.kenmei;
  c3.innerHTML = line.bukyoku;
  c4.innerHTML = line.kasyo;
  c5.innerHTML = line.gyoshu;
  c6.innerHTML = line.biko;
}

//file upload
function upload() {
  document.getElementById('mform').action = '/fupload';
}

//file dowload
function download() {
  document.getElementById('mform').action = '/fdownload';
}

// save hidden data before submit
function saveInfo() {
  var nendo = document.getElementById("nendo").value;
  document.getElementById("hNendo").innerHTML = nendo;
  var chotatsuKbnNo = document.getElementById("chotatsuKbnNo").value;
  document.getElementById("hChotatsuKbnNo").innerHTML = chotatsuKbnNo;
  console.log('form.nendo=' + nendo);
  return true;
}

// create select options
function createSelOption(selId, map) {
  var element = document.getElementById(selId);
  while (element.firstChild)
    element.removeChild(element.firstChild);

  var keys=[];
  for(var key in map)
    keys.push(key);
  keys.sort(mapKeyCompare);
  
  for (ikey in keys) {
    let op = document.createElement("option");
    key = keys[ikey];
    op.value = key;
    op.text = map[key];
//    console.log('key=' + key);
//    console.log('value=' + map[key]);
    document.getElementById(selId).appendChild(op);
  }
}

//comparision definition
function mapKeyCompare(a,b) {
  return a-b;    
}

