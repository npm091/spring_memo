package com.tmc.wata.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.stereotype.Service;

import com.tmc.wata.model.RequestApi;
import com.tmc.wata.model.RegisterTable;

@Service
public class RegisterService
{
  /**
   * aquire nendoList
   *
   * @return
   */
  public RequestApi getSelectList(String nendo, String chotatsuKbnNo) {
    RequestApi api = new RequestApi();
    api.setNendo(nendo);
    api.setChotatsuKbnNo(chotatsuKbnNo);
    api.setBukyokuList(getBukyokuList(nendo, chotatsuKbnNo));
    api.setKashoList(getKashoList(nendo, chotatsuKbnNo));
    api.setGyoshuList(getGyoshuList(nendo, chotatsuKbnNo));
    return api;
  }

  /**
   * aquire nendoList
   *
   * @return
   */
  public Map<String, String> getNendoList() {
    Map<String, String> list = new TreeMap<String, String>();
    list.put("2016", "H28");
    list.put("2017", "H29");
    list.put("2018", "H30");
    return list;
  }

  /**
   * aquire ChotatsuKbnList
   *
   * @return
   */
  public Map<String, String> getChotatsuKbnList() {
    Map<String, String> list = new TreeMap<String, String>();
    list.put("01", "道路工事");
    list.put("02", "建設工事");
    list.put("03", "そのほか");
    return list;
  }

  /**
   * aquire bukyokuList
   *
   * @return
   */
  public Map<String, String> getBukyokuList(String nendo, String chotatsuKbnNo) {
    Map<String, String> list = new TreeMap<String, String>();
    list.put("101", "契約部" + nendo + chotatsuKbnNo);
    list.put("102", "土木部" + nendo + chotatsuKbnNo);
    list.put("103", "施設部" + nendo + chotatsuKbnNo);
    return list;
  }

  /**
   * aquire kashoList
   *
   * @return
   */
  public Map<String, String> getKashoList(String nendo, String chotatsuKbnNo) {
    Map<String, String> list = new TreeMap<String, String>();
    list.put("000", " ");
    list.put("301", "契約課" + nendo + chotatsuKbnNo);
    list.put("302", "建設課" + nendo + chotatsuKbnNo);
    list.put("303", "土木課" + nendo + chotatsuKbnNo);
    return list;
  }

  /**
   * aquire gyoishuList
   *
   * @return
   */
  public Map<String, String> getGyoshuList(String nendo, String chotatsuKbnNo) {
    Map<String, String> list = new TreeMap<String, String>();
    list.put("000", " ");
    list.put("401", "建設" + nendo + chotatsuKbnNo);
    list.put("402", "道路" + nendo + chotatsuKbnNo);
    list.put("403", "建築" + nendo + chotatsuKbnNo);
    return list;
  }

  /**
   * aquire nendoList
   *
   * @return
   */
  public List<RegisterTable> getTableList(String nendo, String chotatsuKbnNo) {
    List<RegisterTable> list = new ArrayList<RegisterTable>();
    for (int i = 0; i < 10; i++) {
      String no = String.format("%02d:", i + 1);
      String jiki = String.valueOf((i % 4) + 1) + "四半期";
      String kenmei = "件名" + no + nendo + chotatsuKbnNo;
      String bukyoku = "部局" + no + nendo + chotatsuKbnNo;
      String kasho = "課所" + no + nendo + chotatsuKbnNo;
      String gyoushu = "業種" + no + nendo + chotatsuKbnNo;
      String biko = "備考" + no + nendo + chotatsuKbnNo;
      RegisterTable data = new RegisterTable(jiki, kenmei, bukyoku, kasho, gyoushu, biko);
      list.add(data);
    }
    return list;
  }

  /**
   * aquire nendoList
   *
   * @return
   */
  public String getTableData(String nendo, String chotatsuKbnNo) {
    StringBuilder buff = new StringBuilder();
    List<RegisterTable> list = getTableList(nendo, chotatsuKbnNo);
    for (RegisterTable data : list) {
      buff.append("\"" + data.getJiki() + "\",");
      buff.append("\"" + data.getKenmei() + "\",");
      buff.append("\"" + data.getBukyoku() + "\",");
      buff.append("\"" + data.getKasyo() + "\",");
      buff.append("\"" + data.getGyoshu() + "\",");
      buff.append("\"" + data.getBiko() + "\"\n");
    }
    return buff.toString();
  }
}
