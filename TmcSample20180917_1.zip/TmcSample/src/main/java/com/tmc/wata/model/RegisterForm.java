package com.tmc.wata.model;

import java.io.Serializable;
import java.util.Map;

import javax.validation.constraints.NotNull;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
public class RegisterForm implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 1L;

  private String nendo;

  private String chotatsuKbnNo;

  private String bukyokuNo;

  private String kashoNo;

  private String gyoshuNo;

  private Map<String, String> nendoList;

  private Map<String, String> chotatsuKbnList;

  private Map<String, String> bukyokuList;

  private Map<String, String> kashoList;

  private Map<String, String> gyoshuList;

  @NotNull
  private MultipartFile uploadFile;
}
