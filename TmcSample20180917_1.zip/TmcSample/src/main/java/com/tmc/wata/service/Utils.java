package com.tmc.wata.service;

import java.util.Map;

public class Utils
{
  /**
   * Mapの先頭のキーを返す
   * 
   * @param map
   * @return
   */
  public static String getMapFKey(Map<String, String> map) {
    for (String key : map.keySet()) {
      return key;
    }
    return null;
  }
}
