package com.tmc.wata;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.tmc.wata.model.User;

import net.sf.json.JSONObject;

/**
 * Handles requests for the application home page.
 */
@Controller
public class MainController extends HttpServlet
{
  /**
   * 
   */
  private static final long serialVersionUID = 1L;
  
  private static final Logger logger = LoggerFactory.getLogger(MainController.class);

  private static Map<String, String> chotatsuList = new HashMap<String, String>() {
      {put("2016", "建設工事１,建設工事２,建設工事３");}
      {put("2017", "電気工事１,電気工事２,電気工事３");}
      {put("2018", "道路工事１,道路工事２,道路工事３");}
  };


/**
   * 
   * @param locale
   * @param model
   * @return
   */
  @RequestMapping(value = "/register", method = RequestMethod.GET)
  
  public String register(Locale locale, Model model) {

    return "torokuList";
  }

  @Override
  @RequestMapping(value = "/requestAjax", method = RequestMethod.POST)
  public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
    logger.info("request from ajax");
    
    try {

      // パラメータ取得
      String nendo = req.getParameter("nendo");
      logger.info("parameter[nendo]={}", nendo);

      // ヘッダ設定
      res.setContentType("application/text;charset=UTF-8"); 

      //pwオブジェクト
      PrintWriter pw = res.getWriter();
      pw.print(chotatsuList.get(nendo));

      //クローズ
      pw.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * request from javascript by ajax
   * 
   * @param locale
   * @param model
   * @return
   */
  @RequestMapping(value = "/requestAjax2", method = RequestMethod.POST)
  public String requestAjax(Locale locale, ModelAndView mv) {

    logger.info("request from ajax");
    return "seltest1";
  }

  /**
   * 
   * @param locale
   * @param model
   * @return
   */
  @RequestMapping(value = "/select", method = RequestMethod.GET)
  public String seltest1(Locale locale, Model model) {

    return "seltest1";
  }

  @RequestMapping(value = "/system", method = RequestMethod.GET)
  public String system(Locale locale, Model model) {
    model.addAttribute("user", setupUser("001", 2));
    model.addAttribute("allUsers", getUserList());
    model.addAttribute("wardcodeList", new TreeMap<String, String>());
    model.addAttribute("targetUser", "001");

    return "accountList";
  }

  @RequestMapping(value = "/system/account/data", method = RequestMethod.GET)
  public ModelAndView getListAccountData(ModelAndView mv) {
    List<User> users = getUserList();
    mv.addObject("user", setupUser("001", 2));
    mv.addObject("allUsers", users);
    mv.setViewName("fragments/account :: list");
    return mv;
  }

  private List<User> getUserList() {
    List<User> list = new ArrayList<User>();
    
    list.add(setupUser("001", 1));
    list.add(setupUser("002", 1));
    return list;
  }

  private User setupUser(String userid, Integer privilege ) {
    User user = new User();
    user.setUserid(userid);
    user.setPassword("");
    user.setPrivilege(privilege);
    return user;
  }
  
  /**
   * index
   * 
   * @param locale
   * @param model
   * @return
   */
  @RequestMapping(value = "/", method = RequestMethod.GET)
  public String root(Locale locale, Model model) {
    return "index";
  }

  /**
   * home sample
   * 
   * @param locale
   * @param model
   * @return
   */
  @RequestMapping(value = "/home", method = RequestMethod.GET)
  public String home(Locale locale, Model model) {
    logger.info("Welcome home! The client locale is {}.", locale);

    Date date = new Date();
    DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
    String formattedDate = dateFormat.format(date);
    model.addAttribute("serverTime", formattedDate);

    return "home";
  }
  
}
