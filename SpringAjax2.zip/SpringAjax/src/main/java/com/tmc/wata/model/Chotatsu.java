package com.tmc.wata.model;

import java.util.List;

import lombok.Data;

@Data
public class Chotatsu
{
  private List<String> list;
}
